# Alec Malenfant

# CS 46200-001 002 Intro to AI

# Oct 03 2024

# Assignment 2

This is a K nearest neighbor assignment. Problem 1 finds the closest k points to a test point from a user defined set of points. Problem 2 classifies data using K nearest neighbor, calculates stats about the model, and then graphs the data on an ROC curve. You can find more information about each problem in the corresponding readme

<br/>readme-1.md => Assignmen02-Problem01.py
<br/>readme-2.md => Assignmen02-Problem02.py
